
interface PostHeaderProps {
    postedBy?: string,
    image?: any,
    createdAt?: string,
    isEdited?: boolean
}

export default PostHeaderProps